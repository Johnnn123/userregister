<?php
	//error_reporting(0);
	ini_set('memory_limit', '-1');
	if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start("ob_gzhandler"); else ob_start();
	session_start();
	$serverhost="localhost";
	$serveruser="root";
	$serverpassword="";
	$serverdatabase="user_registration";
	$serverconnection=mysqli_connect($serverhost,$serveruser,$serverpassword, $serverdatabase) or die('I AM DEAD');
	
	function escapestring($string)
	{
		global $serverconnection;
		$string=str_ireplace(
		array('column_name', 'count(mysql', 'count(table_name)', 'CREATE USER', 'DROP USER', 'information_schema', 'information_schema.schemata', 'information_schema.tables', 'mysql', 'select database', 'schema_name', 'table_name', 'table_schema', 'type(mysql', 'UNION ALL', 'union select'),
		array('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
		$string);
		
		$stringnew=mysqli_real_escape_string($serverconnection, htmlspecialchars($string,ENT_QUOTES));
		return $stringnew;
	}
	
	function unescapestring($string)
	{
		$stringnew=stripslashes(htmlspecialchars_decode($string,ENT_QUOTES));
		return $stringnew;
	}
	
	function mysqlquery($string)
	{
		global $serverconnection;
		return @mysqli_query($serverconnection, $string);
	}
	
	function mysqlfetcharray($string)
	{
		return @mysqli_fetch_assoc($string);
	}
	
	function mysqlinsertid()
	{
		global $serverconnection; 
		return mysqli_insert_id($serverconnection); 
	}
	
	function mysqlnumrows($string)
	{
		return @mysqli_num_rows($string);
	}
	
	function mysqlerror()
	{
		global $serverconnection; 
		return  mysqli_error($serverconnection);
	}
	
	function mysqlclose()
	{
		global $serverconnection; 
		mysqli_close($serverconnection);
	}
?>