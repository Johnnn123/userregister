<?php
	include_once("include/config.php");
	if(!isset($_SESSION['i_login']))
	{
		header("Location:index.php");
		exit;
	}
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>User Registration</title>
	<style>
		html, body
		{
			background-color: #000000;
			height: 99%;
   			width: 99%;
		}
		.container_1{
			position: relative;
			width: 100%;
			height:100%; 
			display: block;	
		}
		
		.header
		{
			position: absolute;
			top: 0px;
			right: 0px;
		}
		
		.bottom
		{
			position: absolute;
			bottom: 0px;
			left: 0px;
		}
	
	</style>
	<link href="css/rain.css" type="text/css"  rel="stylesheet" />
	<link href="css/hererain.css" type="text/css"  rel="stylesheet" />
</head>

<body>
	<div class="container_1">
		<div class="header">
			<img src="images/head.png" width="250" />
		</div>
	
		<div class="login-page">
		  <div class="form">
				<?php
			  		echo $msg; 
				?>
			  <form class="login-form" name="login_form" id="login_form" method="post" action="logout.php">
				  <p>User Name: <?php echo $_SESSION['user_email']; ?></p>
				  <button>log-Out</button>
			</form>
		  </div>
		</div>
		<div class="bottom">
			<img src="images/footer.png" width="500" />
		</div>
		
		<div class="snow layer1 a"></div>
		<div class="snow layer1"></div> 
		<div class="snow layer2 a"></div>
		<div class="snow layer2"></div>
		<div class="snow layer3 a"></div>
		<div class="snow layer3"></div>
	</div>
</body>
</html>
