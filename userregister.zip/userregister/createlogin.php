<?php
	include_once("include/config.php");
	if(isset($_SESSION['i_login']))
	{
		header("Location:afterlogin.php");
		exit;
	}

	if(isset($_POST['username']) and isset($_POST['password']) and isset($_POST['captcha_code']))
	{
		$username=escapestring($_POST['username']);
		$password=escapestring(trim($_POST['password']));
		
		if (!filter_var($username, FILTER_VALIDATE_EMAIL)) 
		{
			$msg="<span style='color:red'>Error!! Invalid Email address!</span>";// Captcha verification is incorrect.
			$error=1;
		}
		else
		{
			if (trim($password)=="" or strlen($password)<6) 
			{
				$msg="<span style='color:red'>Error!! Invalid Password!</span>";// Captcha verification is incorrect.
				$error=1;
			}
			else
			{
				if(empty($_SESSION['captcha_code'] ) || strcasecmp($_SESSION['captcha_code'], $_POST['captcha_code']) != 0)
				{	
					$msg="<span style='color:red'>The Validation code does not match!</span>";// Captcha verification is incorrect.
					$error=1;
				}
				else
				{
					$password_1=md5(trim($password));
					if(!mysqlnumrows(mysqlquery("select s_no from tab_user_registration where user_email='".$username."'")))
					{
						if(mysqlquery("insert into tab_user_registration (user_email, user_password) values('".$username."', '".$password_1."')"))
						{
							$suc=1;
							$msg="<span style='color:green'>Alert: User Add Sucessfully.</span>";
						}
						else
						{
							$msg="<span style='color:red'>Error!! Unable to Add User</span>";
							$error=1;
						}
					}
					else
					{
						$error=1;
						$msg="<span style='color:red'>Error!! Username Already Exist.</span>";
					}
				}
			}
		}
	}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>User Registration</title>
	<style>
		html, body
		{
			background-color: #000000;
			height: 99%;
   			width: 99%;
		}
		.container_1{
			position: relative;
			width: 100%;
			height:100%; 
			display: block;	
		}
		
		.header
		{
			position: absolute;
			top: 0px;
			right: 0px;
		}
		
		.bottom
		{
			position: absolute;
			bottom: 0px;
			left: 0px;
		}
	
	</style>
	<link href="css/rain.css" type="text/css"  rel="stylesheet" />
	<link href="css/hererain.css" type="text/css"  rel="stylesheet" />
</head>

<body>
	<div class="container_1">
		<div class="header">
			<img src="images/head.png" width="250" />
		</div>
		<form class="login-form" name="login_form" id="login_form" method="post" action="createlogin.php">
			<div class="login-page">
			  <div class="form">
				<?php
			  		echo $msg; 
				?>
				<form class="register-form">
				  	<input type="text" placeholder="username" name="username" value="<?php if($error==1) {echo unescapestring($username);} ?>" />
				  <input type="password" placeholder="password" name="password" value="<?php if($error==1) {echo unescapestring($password);} ?>" />
				  <input id="captcha_code" name="captcha_code" type="text" placeholder="Enter Exact Code Shown Below" />
				  <img src="captcha.php?rand=<?php echo rand();?>" id='captchaimg'>
				  	<button>create</button>
				  	<p class="message">Already registered? <a href="index.php">Sign In</a></p>
				</form>
			  </div>
			</div>	
		</form>
		
		<div class="bottom">
			<img src="images/footer.png" width="500" />
		</div>
		
		<div class="snow layer1 a"></div>
		<div class="snow layer1"></div> 
		<div class="snow layer2 a"></div>
		<div class="snow layer2"></div>
		<div class="snow layer3 a"></div>
		<div class="snow layer3"></div>
	</div>
</body>
</html>
